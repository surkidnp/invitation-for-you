package com.example;

import com.example.db.DatabaseConnection;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

public class App extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {
            // Проверка подключения к базе данных при запуске приложения
            checkDatabaseConnection();

            // Загрузка экрана входа вместо главного окна
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            Parent root = loader.load();

            Scene scene = new Scene(root);

            primaryStage.setTitle("Система бронирования отеля");
            primaryStage.setScene(scene);
            primaryStage.show();

            System.out.println("Приложение успешно запущено");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Ошибка запуска приложения", e.getMessage(), AlertType.ERROR);
        }
    }

    private void checkDatabaseConnection() {
        // Проверяем подключение к базе данных
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.println("Успешное подключение к базе данных!");
        } catch (SQLException e) {
            System.err.println("Ошибка подключения к базе данных: " + e.getMessage());
            e.printStackTrace();
            showAlert("Ошибка базы данных",
                    "Не удалось подключиться к базе данных: " + e.getMessage(),
                    AlertType.ERROR);
        }
    }

    private void showAlert(String title, String message, AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @Override
    public void stop() {
        System.out.println("Приложение завершает работу");
        // Закрываем пул соединений при завершении работы приложения
        DatabaseConnection.closePool();
    }

    public static void main(String[] args) {
        launch(args);
    }
}