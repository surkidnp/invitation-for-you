package com.example.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.sql.Timestamp;
import java.time.LocalDate;

public class Booking {
    private final IntegerProperty id = new SimpleIntegerProperty(this, "id", 0);
    private Person guest;
    private Room room;
    private final ObjectProperty<LocalDate> checkInDate = new SimpleObjectProperty<>(this, "checkInDate");
    private final ObjectProperty<LocalDate> checkOutDate = new SimpleObjectProperty<>(this, "checkOutDate");
    private final StringProperty status = new SimpleStringProperty(this, "status");
    private final StringProperty guestName = new SimpleStringProperty(this, "guestName");
    private final StringProperty roomNumber = new SimpleStringProperty(this, "roomNumber");
    private Timestamp createdAt;

    // Дополнительные поля для ID
    private int personId;
    private int roomId;

    // Constructor
    public Booking(int id, Person guest, Room room, LocalDate checkInDate, LocalDate checkOutDate, String status) {
        setId(id);
        this.guest = guest;
        this.room = room;
        setCheckInDate(checkInDate);
        setCheckOutDate(checkOutDate);
        setStatus(status);

        if (guest != null) {
            setGuestName(guest.getFirstName() + " " + guest.getLastName());
            setPersonId(guest.getId());
        }

        if (room != null) {
            setRoomNumber(room.getRoomNumber());
            setRoomId(room.getId());
        }
    }

    // Default constructor
    public Booking() {
    }

    // Getters and setters
    public int getId() {
        return id.get();
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public Person getGuest() {
        return guest;
    }

    public void setGuest(Person guest) {
        this.guest = guest;
        if (guest != null) {
            setGuestName(guest.getFirstName() + " " + guest.getLastName());
            setPersonId(guest.getId());
        }
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
        if (room != null) {
            setRoomNumber(room.getRoomNumber());
            setRoomId(room.getId());
        }
    }

    public LocalDate getCheckInDate() {
        return checkInDate.get();
    }

    public void setCheckInDate(LocalDate checkInDate) {
        this.checkInDate.set(checkInDate);
    }

    public ObjectProperty<LocalDate> checkInDateProperty() {
        return checkInDate;
    }

    public LocalDate getCheckOutDate() {
        return checkOutDate.get();
    }

    public void setCheckOutDate(LocalDate checkOutDate) {
        this.checkOutDate.set(checkOutDate);
    }

    public ObjectProperty<LocalDate> checkOutDateProperty() {
        return checkOutDate;
    }

    public String getStatus() {
        return status.get();
    }

    public void setStatus(String status) {
        this.status.set(status);
    }

    public StringProperty statusProperty() {
        return status;
    }

    public String getGuestName() {
        return guestName.get();
    }

    public void setGuestName(String guestName) {
        this.guestName.set(guestName);
    }

    public StringProperty guestNameProperty() {
        return guestName;
    }

    public String getRoomNumber() {
        return roomNumber.get();
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber.set(roomNumber);
    }

    public StringProperty roomNumberProperty() {
        return roomNumber;
    }

    public int getPersonId() {
        return personId;
    }

    public void setPersonId(int personId) {
        this.personId = personId;
    }

    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
}