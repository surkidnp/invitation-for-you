package com.example.model;

import javafx.beans.property.*;

import java.math.BigDecimal;

public class Service {
    private final IntegerProperty id = new SimpleIntegerProperty(this, "id");
    private final StringProperty name = new SimpleStringProperty(this, "name");
    private final StringProperty description = new SimpleStringProperty(this, "description");
    private final ObjectProperty<BigDecimal> price = new SimpleObjectProperty<>(this, "price");

    public Service() {
        setPrice(BigDecimal.ZERO); // Значение по умолчанию
        setName("");
        setDescription("");
    }

    public Service(int id, String name, String description, BigDecimal price) {
        setId(id);
        setName(name);
        setDescription(description);
        setPrice(price);
    }

    public int getId() {
        return id.get();
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public String getName() {
        return name.get();
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public StringProperty nameProperty() {
        return name;
    }

    public String getDescription() {
        return description.get();
    }

    public void setDescription(String description) {
        this.description.set(description);
    }

    public StringProperty descriptionProperty() {
        return description;
    }

    public BigDecimal getPrice() {
        return price.get();
    }

    public void setPrice(BigDecimal price) {
        this.price.set(price);
    }

    public ObjectProperty<BigDecimal> priceProperty() {
        return price;
    }

    @Override
    public String toString() {
        return name.get() + " (" + price.get() + ")";
    }
}