package com.example.model;

import javafx.beans.property.*;

import java.math.BigDecimal;

public class Room {
    private final IntegerProperty id = new SimpleIntegerProperty(this, "id");
    private final StringProperty roomNumber = new SimpleStringProperty(this, "roomNumber");
    private final StringProperty roomType = new SimpleStringProperty(this, "roomType");
    private final ObjectProperty<BigDecimal> price = new SimpleObjectProperty<>(this, "price");
    private final IntegerProperty capacity = new SimpleIntegerProperty(this, "capacity");
    private final StringProperty status = new SimpleStringProperty(this, "status");
    private final StringProperty description = new SimpleStringProperty(this, "description");

    // Constructor
    public Room(int id, String roomNumber, String roomType, BigDecimal price, int capacity, String status, String description) {
        setId(id);
        setRoomNumber(roomNumber);
        setRoomType(roomType);
        setPrice(price);
        setCapacity(capacity);
        setStatus(status);
        setDescription(description);
    }

    // Конструктор по умолчанию
    public Room() {
        setRoomNumber("");
        setRoomType("");
        setPrice(BigDecimal.ZERO); // Значение по умолчанию
        setStatus("AVAILABLE"); // Значение по умолчанию
        setDescription("");
    }

    // Getters and setters
    public int getId() {
        return id.get();
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public String getRoomNumber() {
        return roomNumber.get();
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber.set(roomNumber);
    }

    public StringProperty roomNumberProperty() {
        return roomNumber;
    }

    public String getRoomType() {
        return roomType.get();
    }

    public void setRoomType(String roomType) {
        this.roomType.set(roomType);
    }

    public StringProperty roomTypeProperty() {
        return roomType;
    }

    public BigDecimal getPrice() {
        return price.get();
    }

    public void setPrice(BigDecimal price) {
        this.price.set(price);
    }

    public ObjectProperty<BigDecimal> priceProperty() {
        return price;
    }

    public int getCapacity() {
        return capacity.get();
    }

    public void setCapacity(int capacity) {
        this.capacity.set(capacity);
    }

    public IntegerProperty capacityProperty() {
        return capacity;
    }

    public String getStatus() {
        return status.get();
    }

    public void setStatus(String status) {
        this.status.set(status);
    }

    public StringProperty statusProperty() {
        return status;
    }

    public String getDescription() {
        return description.get();
    }

    public void setDescription(String description) {
        this.description.set(description);
    }

    public StringProperty descriptionProperty() {
        return description;
    }

    @Override
    public String toString() {
        return getRoomNumber() + " (" + getRoomType() + ")";
    }
}