package com.example.controller;

import com.example.db.DatabaseConnection;
import com.example.model.Room;
import com.example.model.Service;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

public class GuestDashboardController implements Initializable {

    // Убрана таблица номеров
    @FXML private TableView<Service> servicesTable;
    @FXML private TableColumn<Service, String> serviceNameColumn;
    @FXML private TableColumn<Service, BigDecimal> servicePriceColumn;
    @FXML private TableColumn<Service, String> serviceDescriptionColumn;

    @FXML private FlowPane galleryPane;

    private ObservableList<Room> roomsList = FXCollections.observableArrayList();
    private ObservableList<Service> servicesList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Инициализация только таблицы услуг
        serviceNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        servicePriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        serviceDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        servicesTable.setItems(servicesList);

        loadRoomsData();
        loadServicesData();

        // Задержка для инициализации размеров
        Platform.runLater(this::loadRoomGallery);

        // Слушатель изменения размера окна
        galleryPane.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                newScene.widthProperty().addListener((o, oldVal, newVal) -> {
                    loadRoomGallery();
                });
            }
        });
    }

    private void loadRoomsData() {
        roomsList.clear();
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM rooms WHERE status = 'AVAILABLE'")) {

            while (rs.next()) {
                Room room = new Room(
                        rs.getInt("id"),
                        rs.getString("room_number"),
                        rs.getString("room_type"),
                        rs.getBigDecimal("price"),
                        rs.getInt("capacity"),
                        rs.getString("status"),
                        rs.getString("description")
                );
                roomsList.add(room);
            }
        } catch (Exception e) {
            showAlert("Ошибка", "Не удалось загрузить данные о номерах", Alert.AlertType.ERROR);
            e.printStackTrace();
        }
    }

    private void loadServicesData() {
        servicesList.clear();
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM services")) {

            while (rs.next()) {
                Service service = new Service(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getBigDecimal("price")
                );
                servicesList.add(service);
            }
        } catch (Exception e) {
            showAlert("Ошибка", "Не удалось загрузить данные об услугах", Alert.AlertType.ERROR);
            e.printStackTrace();
        }
    }

    private void loadRoomGallery() {
        galleryPane.getChildren().clear();
        if (galleryPane.getWidth() <= 0) return;

        // Рассчитываем ширину контейнера для 3 столбцов
        double containerWidth = (galleryPane.getWidth() - 60) / 3; // 60 = 20*3 (gap)

        for (Room room : roomsList) {
            try {
                // Формируем путь к изображению на основе номера комнаты
                String imagePath = "/images/" + room.getRoomNumber() + ".jpg";
                Image image = new Image(getClass().getResourceAsStream(imagePath));
                ImageView imageView = new ImageView(image);

                // Устанавливаем размеры изображения
                imageView.setFitWidth(containerWidth - 40); // 40 = padding
                imageView.setFitHeight(200);
                imageView.setPreserveRatio(true);
                imageView.setSmooth(true);
                imageView.setCache(true);

                VBox container = new VBox(10,
                        imageView,
                        new Label("Номер " + room.getRoomNumber()),
                        new Label("Тип: " + room.getRoomType()),
                        new Label("Цена: " + room.getPrice() + " руб./сутки"),
                        new Label("Вместимость: " + room.getCapacity() + " чел.")
                );

                container.setAlignment(Pos.TOP_CENTER);
                container.setStyle("-fx-border-color: #e0e0e0; -fx-border-radius: 8; -fx-padding: 15;"
                        + "-fx-background-color: white; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 5, 0, 0, 1);");
                container.setPrefWidth(containerWidth);
                container.setMaxWidth(containerWidth);

                galleryPane.getChildren().add(container);
            } catch (Exception e) {
                System.err.println("Не удалось загрузить изображение для номера " + room.getRoomNumber());
                // Заглушка для отсутствующего изображения
                VBox container = new VBox(10,
                        new Label("Изображение недоступно"),
                        new Label("Номер " + room.getRoomNumber()),
                        new Label("Тип: " + room.getRoomType()),
                        new Label("Цена: " + room.getPrice() + " руб./сутки"),
                        new Label("Вместимость: " + room.getCapacity() + " чел.")
                );

                container.setAlignment(Pos.TOP_CENTER);
                container.setStyle("-fx-border-color: #e0e0e0; -fx-border-radius: 8; -fx-padding: 15;"
                        + "-fx-background-color: #f9f9f9;");
                container.setPrefWidth(containerWidth);
                container.setMaxWidth(containerWidth);

                galleryPane.getChildren().add(container);
            }
        }
    }

    @FXML
    private void handleRefreshRooms() {
        loadRoomsData();
        loadRoomGallery();
    }

    @FXML
    private void handleRefreshServices() {
        loadServicesData();
    }

    @FXML
    private void handleLogout() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) galleryPane.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setTitle("Вход в систему");
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Ошибка", "Не удалось выполнить выход", Alert.AlertType.ERROR);
        }
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}