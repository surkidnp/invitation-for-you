package com.example.controller;

import com.example.db.DatabaseConnection;
import com.example.model.Person;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.ResourceBundle;
import java.text.SimpleDateFormat;
import javafx.scene.control.TableCell;

public class MainController implements Initializable {

    @FXML
    private TableView<Person> personTable;

    @FXML
    private TableColumn<Person, Integer> idColumn;

    @FXML
    private TableColumn<Person, String> firstNameColumn;

    @FXML
    private TableColumn<Person, String> lastNameColumn;

    @FXML
    private TableColumn<Person, String> emailColumn;

    @FXML
    private TableColumn<Person, Date> birthDateColumn;

    @FXML
    private Button refreshButton;

    @FXML
    private Button addButton;

    @FXML
    private Button editButton;

    @FXML
    private Button deleteButton;

    private ObservableList<Person> personList;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Инициализация таблицы
        personList = FXCollections.observableArrayList();

        // Настройка колонок таблицы с явной привязкой к свойствам
        idColumn.setCellValueFactory(cellData -> cellData.getValue().idProperty().asObject());
        firstNameColumn.setCellValueFactory(cellData -> cellData.getValue().firstNameProperty());
        lastNameColumn.setCellValueFactory(cellData -> cellData.getValue().lastNameProperty());
        emailColumn.setCellValueFactory(cellData -> cellData.getValue().emailProperty());

        // Для даты рождения нужен специальный форматтер
        birthDateColumn.setCellValueFactory(cellData -> cellData.getValue().birthDateProperty());
        birthDateColumn.setCellFactory(column -> {
            TableCell<Person, Date> cell = new TableCell<Person, Date>() {
                private final SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");

                @Override
                protected void updateItem(Date item, boolean empty) {
                    super.updateItem(item, empty);
                    if(empty || item == null) {
                        setText(null);
                    } else {
                        setText(format.format(item));
                    }
                }
            };
            return cell;
        });

        // Связываем таблицу со списком
        personTable.setItems(personList);

        // Загрузка данных из базы
        loadDataFromDatabase();
    }

    private void loadDataFromDatabase() {
        // Сохраняем выделенный элемент, чтобы восстановить его после обновления
        Person selectedPerson = personTable.getSelectionModel().getSelectedItem();
        int selectedId = selectedPerson != null ? selectedPerson.getId() : -1;

        // Очищаем список перед загрузкой новых данных
        personList.clear();

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Проверка соединения
            if (conn != null && !conn.isClosed()) {
                System.out.println("Database connected successfully");
            } else {
                System.out.println("Database connection failed");
                showAlert("Ошибка", "Не удалось подключиться к базе данных");
                return;
            }

            try (PreparedStatement stmt = conn.prepareStatement("SELECT * FROM persons");
                 ResultSet rs = stmt.executeQuery()) {

                while (rs.next()) {
                    Person person = new Person(
                            rs.getInt("id"),
                            rs.getString("first_name"),
                            rs.getString("last_name"),
                            rs.getString("email"),
                            rs.getDate("birth_date")
                    );
                    personList.add(person);
                }
            }

            // Восстанавливаем выделение если нужно
            if (selectedId != -1) {
                for (Person p : personList) {
                    if (p.getId() == selectedId) {
                        personTable.getSelectionModel().select(p);
                        break;
                    }
                }
            }

            // Обновляем таблицу
            personTable.refresh();

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Ошибка загрузки данных", e.getMessage());
        }
    }

    @FXML
    private void handleRefresh() {
        loadDataFromDatabase();
    }

    @FXML
    private void handleAdd() {
        try {
            // Загрузка FXML формы
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/person_form.fxml"));
            Parent root = loader.load();

            // Создание нового диалогового окна
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Добавление новой записи");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(personTable.getScene().getWindow());

            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            // Получение контроллера
            PersonFormController controller = loader.getController();
            // Создаем нового человека
            controller.setPerson(new Person());

            // Отображение диалогового окна и ожидание его закрытия
            dialogStage.showAndWait();

            // После закрытия окна проверяем, нажал ли пользователь "Сохранить"
            if (controller.isSaveClicked()) {
                Person newPerson = controller.getPerson();
                // Сохранение новой записи в базу данных
                savePerson(newPerson);
            }
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Ошибка", "Не удалось открыть форму: " + e.getMessage());
        }
    }

    private void savePerson(Person person) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO persons (first_name, last_name, email, birth_date) VALUES (?, ?, ?, ?)",
                     PreparedStatement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, person.getFirstName());
            stmt.setString(2, person.getLastName());
            stmt.setString(3, person.getEmail());

            if (person.getBirthDate() != null) {
                stmt.setDate(4, new java.sql.Date(person.getBirthDate().getTime()));
            } else {
                stmt.setNull(4, java.sql.Types.DATE);
            }

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                // Получаем сгенерированный ID
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        person.setId(generatedKeys.getInt(1));
                        showAlert("Успех", "Запись успешно добавлена");

                        // Обновляем таблицу вместо ручного добавления записи
                        loadDataFromDatabase();
                    }
                }
            } else {
                showAlert("Ошибка", "Не удалось добавить запись");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Ошибка сохранения", e.getMessage());
        }
    }

    @FXML
    private void handleEdit() {
        Person selectedPerson = personTable.getSelectionModel().getSelectedItem();
        if (selectedPerson == null) {
            showAlert("Ошибка", "Выберите запись для редактирования");
            return;
        }

        try {
            // Загрузка FXML формы
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/person_form.fxml"));
            Parent root = loader.load();

            // Создание нового диалогового окна
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Редактирование записи");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(personTable.getScene().getWindow());

            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            // Создаем копию объекта для редактирования
            Person personCopy = new Person(
                    selectedPerson.getId(),
                    selectedPerson.getFirstName(),
                    selectedPerson.getLastName(),
                    selectedPerson.getEmail(),
                    selectedPerson.getBirthDate()
            );

            // Получение контроллера и передача выбранной записи
            PersonFormController controller = loader.getController();
            controller.setPerson(personCopy);

            // Отображение диалогового окна и ожидание его закрытия
            dialogStage.showAndWait();

            // После закрытия окна проверяем, нажал ли пользователь "Сохранить"
            if (controller.isSaveClicked()) {
                Person editedPerson = controller.getPerson();
                // Обновление записи в базе данных
                updatePerson(editedPerson);
            }
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Ошибка", "Не удалось открыть форму: " + e.getMessage());
        }
    }

    private void updatePerson(Person person) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE persons SET first_name = ?, last_name = ?, email = ?, birth_date = ? WHERE id = ?")) {

            stmt.setString(1, person.getFirstName());
            stmt.setString(2, person.getLastName());
            stmt.setString(3, person.getEmail());

            if (person.getBirthDate() != null) {
                stmt.setDate(4, new java.sql.Date(person.getBirthDate().getTime()));
            } else {
                stmt.setNull(4, java.sql.Types.DATE);
            }

            stmt.setInt(5, person.getId());

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                showAlert("Успех", "Запись успешно обновлена");
                // Обновляем таблицу
                loadDataFromDatabase();
            } else {
                showAlert("Ошибка", "Не удалось обновить запись");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Ошибка обновления", e.getMessage());
        }
    }

    @FXML
    private void handleDelete() {
        Person selectedPerson = personTable.getSelectionModel().getSelectedItem();
        if (selectedPerson == null) {
            showAlert("Ошибка", "Выберите запись для удаления");
            return;
        }

        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Подтверждение");
        confirmation.setHeaderText(null);
        confirmation.setContentText("Вы уверены, что хотите удалить запись?");

        if (confirmation.showAndWait().get() == ButtonType.OK) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("DELETE FROM persons WHERE id = ?")) {

                stmt.setInt(1, selectedPerson.getId());
                int rowsAffected = stmt.executeUpdate();

                if (rowsAffected > 0) {
                    personList.remove(selectedPerson);
                    personTable.refresh();
                    showAlert("Успех", "Запись успешно удалена");
                } else {
                    showAlert("Ошибка", "Не удалось удалить запись. Запись не найдена.");
                }

            } catch (SQLException e) {
                e.printStackTrace();
                showAlert("Ошибка удаления", e.getMessage());
            }
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}