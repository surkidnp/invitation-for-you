package com.example.controller;

import com.example.db.DatabaseConnection;
import com.example.model.Booking;
import com.example.model.Person;
import com.example.model.Room;
import com.example.model.Service;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;
import java.time.format.DateTimeFormatter;

public class BookingFormController implements Initializable {

    @FXML
    private ComboBox<Person> guestComboBox;

    @FXML
    private ComboBox<Room> roomComboBox;

    @FXML
    private DatePicker checkInDatePicker;

    @FXML
    private DatePicker checkOutDatePicker;

    @FXML
    private ComboBox<String> statusComboBox;

    @FXML
    private ComboBox<Service> serviceComboBox;

    @FXML
    private TextField quantityField;

    @FXML
    private TableView<BookingService> servicesTable;

    @FXML
    private TableColumn<BookingService, String> serviceNameColumn;

    @FXML
    private TableColumn<BookingService, BigDecimal> servicePriceColumn;

    @FXML
    private TableColumn<BookingService, Integer> serviceQuantityColumn;

    @FXML
    private TableColumn<BookingService, BigDecimal> serviceTotalColumn;

    @FXML
    private Label totalPriceLabel;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private Booking booking;
    private boolean saveClicked = false;

    private ObservableList<Person> guestsList = FXCollections.observableArrayList();
    private ObservableList<Room> roomsList = FXCollections.observableArrayList();
    private ObservableList<Service> servicesList = FXCollections.observableArrayList();
    private ObservableList<BookingService> bookingServices = FXCollections.observableArrayList();

    // Вспомогательный класс для хранения информации о услугах бронирования
    public static class BookingService {
        private final Service service;
        private final int quantity;
        private final BigDecimal total;

        public BookingService(Service service, int quantity) {
            this.service = service;
            this.quantity = quantity;
            this.total = service.getPrice().multiply(new BigDecimal(quantity));
        }

        public Service getService() {
            return service;
        }

        public String getServiceName() {
            return service.getName();
        }

        public BigDecimal getServicePrice() {
            return service.getPrice();
        }

        public int getQuantity() {
            return quantity;
        }

        public BigDecimal getTotal() {
            return total;
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Инициализация статусов
        statusComboBox.setItems(FXCollections.observableArrayList(
                "ACTIVE", "CANCELED", "COMPLETED", "NO_SHOW"));
        statusComboBox.getSelectionModel().selectFirst();

        // Инициализация дат
        checkInDatePicker.setValue(LocalDate.now());
        checkOutDatePicker.setValue(LocalDate.now().plusDays(1));

        // Инициализация таблицы услуг
        serviceNameColumn.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getServiceName()));
        servicePriceColumn.setCellValueFactory(cellData ->
                new SimpleObjectProperty<>(cellData.getValue().getServicePrice()));
        serviceQuantityColumn.setCellValueFactory(cellData ->
                new SimpleIntegerProperty(cellData.getValue().getQuantity()).asObject());
        serviceTotalColumn.setCellValueFactory(cellData ->
                new SimpleObjectProperty<>(cellData.getValue().getTotal()));

        servicesTable.setItems(bookingServices);

        // Настройка ComboBox для гостей
        guestComboBox.setConverter(new StringConverter<Person>() {
            @Override
            public String toString(Person person) {
                return person != null ? person.getFullName() : "";
            }

            @Override
            public Person fromString(String string) {
                return null; // не используется для ComboBox
            }
        });

        // Настройка ComboBox для номеров
        roomComboBox.setConverter(new StringConverter<Room>() {
            @Override
            public String toString(Room room) {
                return room != null ? room.getRoomNumber() + " - " + room.getRoomType() : "";
            }

            @Override
            public Room fromString(String string) {
                return null; // не используется для ComboBox
            }
        });

        // Настройка ComboBox для услуг
        serviceComboBox.setConverter(new StringConverter<Service>() {
            @Override
            public String toString(Service service) {
                return service != null ? service.getName() + " (" + service.getPrice() + " руб.)" : "";
            }

            @Override
            public Service fromString(String string) {
                return null; // не используется для ComboBox
            }
        });

        // Установка значения по умолчанию для количества услуг
        quantityField.setText("1");

        // Добавление слушателей для обновления общей стоимости
        bookingServices.addListener((javafx.collections.ListChangeListener.Change<? extends BookingService> c) -> {
            updateTotalPrice();
        });

        // Добавляем слушатели для обновления общей стоимости при изменении дат или номера
        checkInDatePicker.valueProperty().addListener((obs, oldVal, newVal) -> updateTotalPrice());
        checkOutDatePicker.valueProperty().addListener((obs, oldVal, newVal) -> updateTotalPrice());
        roomComboBox.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> updateTotalPrice());
    }

    /**
     * Устанавливает бронирование для редактирования
     */
    public void setBooking(Booking booking) {
        this.booking = booking;

        // Заполняем поля формы данными из бронирования
        for (Person person : guestsList) {
            if (person.getId() == booking.getPersonId()) {
                guestComboBox.setValue(person);
                break;
            }
        }

        for (Room room : roomsList) {
            if (room.getId() == booking.getRoomId()) {
                roomComboBox.setValue(room);
                break;
            }
        }

        checkInDatePicker.setValue(booking.getCheckInDate());
        checkOutDatePicker.setValue(booking.getCheckOutDate());
        statusComboBox.setValue(booking.getStatus());

        // Загружаем услуги бронирования
        loadBookingServices(booking.getId());
    }
    private void generateReceipt(Booking booking) {
        try {
            // Создаем директорию для чеков, если ее нет
            File receiptsDir = new File("receipts");
            if (!receiptsDir.exists()) {
                receiptsDir.mkdir();
            }

            // Форматируем даты
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");

            // Создаем файл чека
            String fileName = "receipt_" + booking.getId() + "_" + System.currentTimeMillis() + ".txt";
            File file = new File(receiptsDir, fileName);

            try (FileWriter writer = new FileWriter(file)) {
                writer.write("ОТЕЛЬ ПРЕМИУМ\n");
                writer.write("-------------------------------\n");
                writer.write("ЧЕК БРОНИРОВАНИЯ №" + booking.getId() + "\n");
                writer.write("Дата: " + java.time.LocalDate.now() + "\n");
                writer.write("-------------------------------\n");
                writer.write("Гость: " + booking.getGuestName() + "\n");
                writer.write("Номер: " + booking.getRoomNumber() + "\n");
                writer.write("Дата заезда: " + booking.getCheckInDate().format(formatter) + "\n");
                writer.write("Дата выезда: " + booking.getCheckOutDate().format(formatter) + "\n");
                writer.write("Статус: " + booking.getStatus() + "\n");
                writer.write("-------------------------------\n");
                writer.write("УСЛУГИ:\n");

                // Добавляем услуги
                for (BookingService bs : bookingServices) {
                    writer.write(String.format(
                            "- %s: %d x %.2f = %.2f руб.\n",
                            bs.getService().getName(),
                            bs.getQuantity(),
                            bs.getService().getPrice(),
                            bs.getTotal()
                    ));
                }

                // Добавляем стоимость номера
                long days = booking.getCheckOutDate().toEpochDay() - booking.getCheckInDate().toEpochDay();
                BigDecimal roomTotal = roomComboBox.getValue().getPrice().multiply(new BigDecimal(days));
                writer.write(String.format(
                        "\nСтоимость номера: %d дн. x %.2f = %.2f руб.\n",
                        days,
                        roomComboBox.getValue().getPrice(),
                        roomTotal
                ));

                // Итоговая сумма
                BigDecimal total = BigDecimal.ZERO;
                for (BookingService bs : bookingServices) {
                    total = total.add(bs.getTotal());
                }
                total = total.add(roomTotal);

                writer.write("-------------------------------\n");
                writer.write(String.format("ИТОГО: %.2f руб.\n", total));
                writer.write("-------------------------------\n");
                writer.write("Спасибо за выбор нашего отеля!\n");
            }

            // Показываем сообщение о сохранении
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Чек сохранен");
            alert.setHeaderText(null);
            alert.setContentText("Чек сохранен в файл:\n" + file.getAbsolutePath());
            alert.showAndWait();

        } catch (IOException e) {
            showAlert("Ошибка", "Не удалось сохранить чек: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    // В метод handleSave добавляем вызов генерации чека
    @FXML
    private void handleSave() {
        if (isInputValid()) {
            // ... существующий код ...

            if (saveBookingToDatabase()) {
                // Генерируем чек
                generateReceipt(booking);

                saveClicked = true;
                closeDialog();
            }
        }
    }
    /**
     * Загружает услуги бронирования из базы данных
     */
    private void loadBookingServices(int bookingId) {
        bookingServices.clear();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT bs.service_id, bs.quantity, s.name, s.price, s.description " +
                             "FROM booking_services bs " +
                             "JOIN services s ON bs.service_id = s.id " +
                             "WHERE bs.booking_id = ?")) {

            stmt.setInt(1, bookingId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Service service = new Service(
                            rs.getInt("service_id"),
                            rs.getString("name"),
                            rs.getString("description"),
                            rs.getBigDecimal("price")
                    );

                    int quantity = rs.getInt("quantity");
                    bookingServices.add(new BookingService(service, quantity));
                }
            }

            updateTotalPrice();

        } catch (SQLException e) {
            showAlert("Ошибка", "Ошибка при загрузке услуг бронирования: " + e.getMessage(), Alert.AlertType.ERROR);
            e.printStackTrace();
        }
    }

    /**
     * Устанавливает список гостей
     */
    public void setGuestsList(ObservableList<Person> guestsList) {
        this.guestsList = guestsList;
        guestComboBox.setItems(this.guestsList);

        if (!guestsList.isEmpty()) {
            guestComboBox.getSelectionModel().selectFirst();
        }
    }

    /**
     * Устанавливает список номеров
     */
    public void setRoomsList(ObservableList<Room> roomsList) {
        this.roomsList = roomsList;
        roomComboBox.setItems(this.roomsList);

        if (!roomsList.isEmpty()) {
            roomComboBox.getSelectionModel().selectFirst();
        }
    }

    /**
     * Устанавливает список услуг
     */
    public void setServicesList(ObservableList<Service> servicesList) {
        this.servicesList = servicesList;
        serviceComboBox.setItems(this.servicesList);

        if (!servicesList.isEmpty()) {
            serviceComboBox.getSelectionModel().selectFirst();
        }
    }

    /**
     * Возвращает true, если пользователь нажал Сохранить
     */
    public boolean isSaveClicked() {
        return saveClicked;
    }

    /**
     * Возвращает созданное/отредактированное бронирование
     */
    public Booking getBooking() {
        return booking;
    }

    /**
     * Обработчик кнопки Добавить услугу
     */
    @FXML
    private void handleAddService() {
        Service selectedService = serviceComboBox.getValue();

        if (selectedService == null) {
            showAlert("Ошибка", "Выберите услугу", Alert.AlertType.WARNING);
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityField.getText());
            if (quantity <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            showAlert("Ошибка", "Количество должно быть положительным числом", Alert.AlertType.WARNING);
            return;
        }

        // Проверяем, есть ли уже такая услуга в списке
        for (int i = 0; i < bookingServices.size(); i++) {
            BookingService bs = bookingServices.get(i);
            if (bs.getService().getId() == selectedService.getId()) {
                // Если есть, заменяем на новую с обновленным количеством
                bookingServices.set(i, new BookingService(selectedService, quantity));
                updateTotalPrice();
                return;
            }
        }

        // Если нет, добавляем новую
        bookingServices.add(new BookingService(selectedService, quantity));
        updateTotalPrice();
    }

    /**
     * Обновляет общую стоимость
     */
    private void updateTotalPrice() {
        BigDecimal total = BigDecimal.ZERO;

        for (BookingService bs : bookingServices) {
            total = total.add(bs.getTotal());
        }

        // Добавляем стоимость номера, если он выбран
        Room selectedRoom = roomComboBox.getValue();
        if (selectedRoom != null) {
            LocalDate checkIn = checkInDatePicker.getValue();
            LocalDate checkOut = checkOutDatePicker.getValue();

            if (checkIn != null && checkOut != null) {
                long days = checkOut.toEpochDay() - checkIn.toEpochDay();
                if (days > 0) {
                    BigDecimal roomTotal = selectedRoom.getPrice().multiply(new BigDecimal(days));
                    total = total.add(roomTotal);
                }
            }
        }

        totalPriceLabel.setText(total + " руб.");
    }

    /**
     * Обработчик кнопки Сохранить
     */
    @FXML
    private void handleSave() {
        if (isInputValid()) {
            if (booking == null) {
                booking = new Booking();
            }

            Person selectedGuest = guestComboBox.getValue();
            Room selectedRoom = roomComboBox.getValue();

            booking.setPersonId(selectedGuest.getId());
            booking.setRoomId(selectedRoom.getId());
            booking.setCheckInDate(checkInDatePicker.getValue());
            booking.setCheckOutDate(checkOutDatePicker.getValue());
            booking.setStatus(statusComboBox.getValue());

            // Дополнительные поля для отображения
            booking.setGuestName(selectedGuest.getFullName());
            booking.setRoomNumber(selectedRoom.getRoomNumber());

            if (saveBookingToDatabase()) {
                saveClicked = true;
                closeDialog();
            }
        }
    }

    /**
     * Сохраняет бронирование в базу данных
     */
    private boolean saveBookingToDatabase() {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false); // Начинаем транзакцию

            if (booking.getId() == 0) {
                // Новое бронирование
                try (PreparedStatement stmt = conn.prepareStatement(
                        "INSERT INTO bookings (person_id, room_id, check_in_date, check_out_date, status) " +
                                "VALUES (?, ?, ?, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS)) {

                    stmt.setInt(1, booking.getPersonId());
                    stmt.setInt(2, booking.getRoomId());
                    stmt.setDate(3, java.sql.Date.valueOf(booking.getCheckInDate()));
                    stmt.setDate(4, java.sql.Date.valueOf(booking.getCheckOutDate()));
                    stmt.setString(5, booking.getStatus());

                    int rowsAffected = stmt.executeUpdate();

                    if (rowsAffected > 0) {
                        try (ResultSet rs = stmt.getGeneratedKeys()) {
                            if (rs.next()) {
                                booking.setId(rs.getInt(1));
                                
                                // Обновляем статус номера на "occupied"
                                try (PreparedStatement updateRoomStmt = conn.prepareStatement(
                                        "UPDATE rooms SET status = 'occupied' WHERE id = ?")) {
                                    updateRoomStmt.setInt(1, booking.getRoomId());
                                    updateRoomStmt.executeUpdate();
                                }
                                
                                // Сохраняем услуги бронирования
                                saveBookingServices(conn, booking.getId());
                                conn.commit(); // Фиксируем транзакцию
                                return true;
                            }
                        }
                    }
                }
            } else {
                // Существующее бронирование
                try (PreparedStatement stmt = conn.prepareStatement(
                        "UPDATE bookings SET person_id = ?, room_id = ?, check_in_date = ?, " +
                                "check_out_date = ?, status = ? WHERE id = ?")) {

                    // Сохраняем старый ID номера для проверки изменений
                    int oldRoomId = -1;
                    try (PreparedStatement getOldRoomStmt = conn.prepareStatement(
                            "SELECT room_id FROM bookings WHERE id = ?")) {
                        getOldRoomStmt.setInt(1, booking.getId());
                        try (ResultSet rs = getOldRoomStmt.executeQuery()) {
                            if (rs.next()) {
                                oldRoomId = rs.getInt("room_id");
                            }
                        }
                    }

                    stmt.setInt(1, booking.getPersonId());
                    stmt.setInt(2, booking.getRoomId());
                    stmt.setDate(3, java.sql.Date.valueOf(booking.getCheckInDate()));
                    stmt.setDate(4, java.sql.Date.valueOf(booking.getCheckOutDate()));
                    stmt.setString(5, booking.getStatus());
                    stmt.setInt(6, booking.getId());

                    int rowsAffected = stmt.executeUpdate();

                    if (rowsAffected > 0) {
                        // Если номер изменился, обновляем статусы обоих номеров
                        if (oldRoomId != booking.getRoomId() && oldRoomId != -1) {
                            // Освобождаем старый номер
                            try (PreparedStatement updateOldRoomStmt = conn.prepareStatement(
                                    "UPDATE rooms SET status = 'available' WHERE id = ?")) {
                                updateOldRoomStmt.setInt(1, oldRoomId);
                                updateOldRoomStmt.executeUpdate();
                            }
                        }
                        
                        // Обновляем статус текущего номера, если бронирование активно
                        if (booking.getStatus().equals("ACTIVE")) {
                            try (PreparedStatement updateRoomStmt = conn.prepareStatement(
                                    "UPDATE rooms SET status = 'occupied' WHERE id = ?")) {
                                updateRoomStmt.setInt(1, booking.getRoomId());
                                updateRoomStmt.executeUpdate();
                            }
                        } else if (booking.getStatus().equals("CANCELED") || booking.getStatus().equals("COMPLETED")) {
                            // Если бронирование отменено или завершено, освобождаем номер
                            try (PreparedStatement updateRoomStmt = conn.prepareStatement(
                                    "UPDATE rooms SET status = 'available' WHERE id = ?")) {
                                updateRoomStmt.setInt(1, booking.getRoomId());
                                updateRoomStmt.executeUpdate();
                            }
                        }
                        
                        // Удаляем старые услуги и сохраняем новые
                        try (PreparedStatement deleteStmt = conn.prepareStatement(
                                "DELETE FROM booking_services WHERE booking_id = ?")) {
                            deleteStmt.setInt(1, booking.getId());
                            deleteStmt.executeUpdate();
                        }

                        // Сохраняем услуги бронирования
                        saveBookingServices(conn, booking.getId());
                        conn.commit(); // Фиксируем транзакцию
                        return true;
                    }
                }
            }

            conn.rollback(); // Откатываем транзакцию в случае ошибки

        } catch (SQLException e) {
            try {
                if (conn != null) {
                    conn.rollback(); // Откатываем транзакцию в случае исключения
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            showAlert("Ошибка", "Ошибка при сохранении бронирования: " + e.getMessage(), Alert.AlertType.ERROR);
            e.printStackTrace();
        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return false;
    }

    /**
     * Сохраняет услуги бронирования в базу данных
     */
    private void saveBookingServices(Connection conn, int bookingId) throws SQLException {
        if (!bookingServices.isEmpty()) {
            try (PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO booking_services (booking_id, service_id, quantity) VALUES (?, ?, ?)")) {

                for (BookingService bs : bookingServices) {
                    stmt.setInt(1, bookingId);
                    stmt.setInt(2, bs.getService().getId());
                    stmt.setInt(3, bs.getQuantity());
                    stmt.addBatch();
                }

                stmt.executeBatch();
            }
        }
    }

    /**
     * Обработчик кнопки Отмена
     */
    @FXML
    private void handleCancel() {
        closeDialog();
    }

    /**
     * Закрывает диалоговое окно
     */
    private void closeDialog() {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }

    /**
     * Проверяет валидность ввода пользователя
     */
    private boolean isInputValid() {
        String errorMessage = "";

        if (guestComboBox.getValue() == null) {
            errorMessage += "Выберите гостя\n";
        }

        if (roomComboBox.getValue() == null) {
            errorMessage += "Выберите номер\n";
        }

        if (checkInDatePicker.getValue() == null) {
            errorMessage += "Выберите дату заезда\n";
        }

        if (checkOutDatePicker.getValue() == null) {
            errorMessage += "Выберите дату выезда\n";
        }

        if (checkInDatePicker.getValue() != null && checkOutDatePicker.getValue() != null) {
            if (checkInDatePicker.getValue().isAfter(checkOutDatePicker.getValue())) {
                errorMessage += "Дата заезда не может быть позже даты выезда\n";
            }
        }

        if (errorMessage.isEmpty()) {
            return true;
        } else {
            showAlert("Ошибка валидации", errorMessage, Alert.AlertType.ERROR);
            return false;
        }
    }

    /**
     * Показывает диалоговое окно с ошибкой
     */
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}