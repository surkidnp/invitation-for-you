package com.example.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class LoginController {

    @FXML
    private TextField loginField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label errorLabel;

    @FXML
    private Button loginButton;

    @FXML
    private Button guestLoginButton;

    private static final String ADMIN_LOGIN = "Admin";
    private static final String ADMIN_PASSWORD = "Admin";

    @FXML
    private void handleLogin() {
        String login = loginField.getText();
        String password = passwordField.getText();

        if (login.equals(ADMIN_LOGIN) && password.equals(ADMIN_PASSWORD)) {
            try {
                loadDashboard("/fxml/admin_dashboard.fxml", "Система управления отелем - Панель администратора");
            } catch (Exception e) {
                showError("Ошибка при загрузке панели администратора: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            showError("Неверный логин или пароль");
        }
    }

    @FXML
    private void handleGuestLogin() {
        loadDashboard("/fxml/guest_dashboard.fxml", "Гостевая панель - Просмотр номеров и услуг");
    }

    private void loadDashboard(String fxmlPath, String title) {
        try {
            URL fxmlUrl = getClass().getResource(fxmlPath);
            if (fxmlUrl == null) {
                showError("Файл " + fxmlPath + " не найден!");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();

            Stage stage = (Stage) loginButton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setTitle(title);
            stage.setScene(scene);
            stage.setMaximized(true);
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            showError("Ошибка при загрузке интерфейса: " + e.getMessage());
        }
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }
}