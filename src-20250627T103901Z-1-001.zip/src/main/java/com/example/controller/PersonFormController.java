package com.example.controller;

import com.example.model.Person;

import java.net.URL;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class PersonFormController implements Initializable {

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private TextField emailField;

    @FXML
    private DatePicker birthDatePicker;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private Person person;

    private boolean saveClicked = false;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Инициализация контроллера
    }

    /**
     * Устанавливает персону для редактирования
     */
    public void setPerson(Person person) {
        this.person = person;

        // Заполняем поля формы данными из объекта
        if (person != null) {
            firstNameField.setText(person.getFirstName());
            lastNameField.setText(person.getLastName());
            emailField.setText(person.getEmail());

            // Устанавливаем дату рождения, если она есть
            if (person.getBirthDate() != null) {
                // Используем преобразование через java.util.Date
                java.util.Date utilDate = new java.util.Date(person.getBirthDate().getTime());
                LocalDate birthDate = utilDate.toInstant()
                        .atZone(ZoneId.systemDefault())
                        .toLocalDate();
                birthDatePicker.setValue(birthDate);
            }
        }
    }
    /**
     * Возвращает отредактированную персону
     */
    public Person getPerson() {
        return person;
    }

    /**
     * Возвращает true, если пользователь нажал кнопку Сохранить
     */
    public boolean isSaveClicked() {
        return saveClicked;
    }

    /**
     * Обработка нажатия на кнопку Сохранить
     */
    @FXML
    private void handleSave() {
        if (isInputValid()) {
            // Копируем данные из полей формы в объект
            person.setFirstName(firstNameField.getText());
            person.setLastName(lastNameField.getText());
            person.setEmail(emailField.getText());

            // Преобразуем LocalDate в java.sql.Date
            if (birthDatePicker.getValue() != null) {
                // Преобразование через java.util.Date
                java.util.Date utilDate = java.util.Date.from(
                        birthDatePicker.getValue()
                                .atStartOfDay(ZoneId.systemDefault())
                                .toInstant()
                );
                person.setBirthDate(new java.sql.Date(utilDate.getTime()));
            } else {
                person.setBirthDate(null);
            }

            saveClicked = true;
            Stage stage = (Stage) saveButton.getScene().getWindow();
            stage.close();
        }
    }
    /**
     * Обработка нажатия на кнопку Отмена
     */
    @FXML
    private void handleCancel() {
        saveClicked = false;

        // Закрываем диалоговое окно
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }

    /**
     * Проверяет введенные пользователем данные
     */
    private boolean isInputValid() {
        String errorMessage = "";

        if (firstNameField.getText() == null || firstNameField.getText().trim().isEmpty()) {
            errorMessage += "Не указано имя!\n";
        }

        if (lastNameField.getText() == null || lastNameField.getText().trim().isEmpty()) {
            errorMessage += "Не указана фамилия!\n";
        }

        if (errorMessage.length() == 0) {
            return true;
        } else {
            // Показываем сообщение об ошибке
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Ошибка ввода");
            alert.setHeaderText(null);
            alert.setContentText(errorMessage);
            alert.showAndWait();

            return false;
        }
    }
}