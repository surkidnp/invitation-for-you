package com.example.controller;

import com.example.db.DatabaseConnection;
import com.example.model.Booking;
import com.example.model.Person;
import com.example.model.Room;
import com.example.model.Service;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;

public class AdminDashboardController implements Initializable {

    // Общие компоненты
    @FXML
    private TabPane tabPane;
    @FXML
    private Label statusLabel;

    // Вкладка номеров
    @FXML
    private Tab roomsTab;
    @FXML
    private TableView<Room> roomsTable;
    @FXML
    private TableColumn<Room, Integer> roomIdColumn;
    @FXML
    private TableColumn<Room, String> roomNumberColumn;
    @FXML
    private TableColumn<Room, String> roomTypeColumn;
    @FXML
    private TableColumn<Room, BigDecimal> roomPriceColumn;
    @FXML
    private TableColumn<Room, Integer> roomCapacityColumn;
    @FXML
    private TableColumn<Room, String> roomStatusColumn;
    @FXML
    private TableColumn<Room, String> roomDescriptionColumn;

    // Вкладка гостей
    @FXML
    private Tab guestsTab;
    @FXML
    private TableView<Person> guestsTable;
    @FXML
    private TableColumn<Person, Integer> guestIdColumn;
    @FXML
    private TableColumn<Person, String> guestFirstNameColumn;
    @FXML
    private TableColumn<Person, String> guestLastNameColumn;
    @FXML
    private TableColumn<Person, String> guestEmailColumn;
    @FXML
    private TableColumn<Person, Date> guestBirthDateColumn;

    // Вкладка бронирований
    @FXML
    private Tab bookingsTab;
    @FXML
    private TableView<Booking> bookingsTable;
    @FXML
    private TableColumn<Booking, Integer> bookingIdColumn;
    @FXML
    private TableColumn<Booking, String> bookingGuestColumn;
    @FXML
    private TableColumn<Booking, String> bookingRoomColumn;
    @FXML
    private TableColumn<Booking, LocalDate> bookingCheckInColumn;
    @FXML
    private TableColumn<Booking, LocalDate> bookingCheckOutColumn;
    @FXML
    private TableColumn<Booking, String> bookingStatusColumn;

    // Вкладка услуг
    @FXML
    private Tab servicesTab;
    @FXML
    private TableView<Service> servicesTable;
    @FXML
    private TableColumn<Service, Integer> serviceIdColumn;
    @FXML
    private TableColumn<Service, String> serviceNameColumn;
    @FXML
    private TableColumn<Service, String> serviceDescriptionColumn;
    @FXML
    private TableColumn<Service, BigDecimal> servicePriceColumn;

    // Списки данных
    private ObservableList<Room> roomsList = FXCollections.observableArrayList();
    private ObservableList<Person> guestsList = FXCollections.observableArrayList();
    private ObservableList<Booking> bookingsList = FXCollections.observableArrayList();
    private ObservableList<Service> servicesList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Инициализация таблицы номеров
        roomIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        roomNumberColumn.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));
        roomTypeColumn.setCellValueFactory(new PropertyValueFactory<>("roomType"));
        roomPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        roomCapacityColumn.setCellValueFactory(new PropertyValueFactory<>("capacity"));
        roomStatusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        roomDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        roomsTable.setItems(roomsList);

        // Инициализация таблицы гостей
        guestIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        guestFirstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        guestLastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        guestEmailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        guestBirthDateColumn.setCellValueFactory(new PropertyValueFactory<>("birthDate"));
        guestsTable.setItems(guestsList);

        // Инициализация таблицы бронирований
        bookingIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        bookingGuestColumn.setCellValueFactory(new PropertyValueFactory<>("guestName"));
        bookingRoomColumn.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));
        bookingCheckInColumn.setCellValueFactory(new PropertyValueFactory<>("checkInDate"));
        bookingCheckOutColumn.setCellValueFactory(new PropertyValueFactory<>("checkOutDate"));
        bookingStatusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        bookingsTable.setItems(bookingsList);

        // Инициализация таблицы услуг
        serviceIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        serviceNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        serviceDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        servicePriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        servicesTable.setItems(servicesList);

        // Загрузка данных
        loadRoomsData();
        loadGuestsData();
        loadBookingsData();
        loadServicesData();

        // Установка обработчиков выбора вкладок
        tabPane.getSelectionModel().selectedItemProperty().addListener((observable, oldTab, newTab) -> {
            if (newTab == roomsTab) {
                loadRoomsData();
            } else if (newTab == guestsTab) {
                loadGuestsData();
            } else if (newTab == bookingsTab) {
                loadBookingsData();
            } else if (newTab == servicesTab) {
                loadServicesData();
            }
        });
    }

    // Методы для вкладки "Номера"
    private void loadRoomsData() {
        roomsList.clear();

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM rooms")) {

            while (rs.next()) {
                Room room = new Room(
                        rs.getInt("id"),
                        rs.getString("room_number"),
                        rs.getString("room_type"),
                        rs.getBigDecimal("price"),
                        rs.getInt("capacity"),
                        rs.getString("status"),
                        rs.getString("description")
                );
                roomsList.add(room);
            }

            statusLabel.setText("Загружено номеров: " + roomsList.size());

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Ошибка", "Ошибка при загрузке номеров: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleAddRoom() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/room_form.fxml"));
            Parent root = loader.load();

            RoomFormController controller = loader.getController();
            controller.setRoom(new Room());

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Добавление номера");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(tabPane.getScene().getWindow());

            // Установка оптимального размера окна
            Scene scene = new Scene(root);
            dialogStage.setScene(scene);
            dialogStage.setMinWidth(450);
            dialogStage.setMinHeight(400);
            dialogStage.setWidth(450);
            dialogStage.setHeight(400);

            dialogStage.showAndWait();

            if (controller.isSaveClicked()) {
                loadRoomsData();
            }
        } catch (IOException e) {
            showAlert("Ошибка", "Ошибка при открытии формы: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleEditRoom() {
        Room selectedRoom = roomsTable.getSelectionModel().getSelectedItem();
        if (selectedRoom == null) {
            showAlert("Предупреждение", "Выберите номер для редактирования", Alert.AlertType.WARNING);
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/room_form.fxml"));
            Parent root = loader.load();

            RoomFormController controller = loader.getController();
            controller.setRoom(selectedRoom);

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Редактирование номера");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(tabPane.getScene().getWindow());

            // Установка оптимального размера окна
            Scene scene = new Scene(root);
            dialogStage.setScene(scene);
            dialogStage.setMinWidth(450);
            dialogStage.setMinHeight(400);
            dialogStage.setWidth(450);
            dialogStage.setHeight(400);

            dialogStage.showAndWait();

            if (controller.isSaveClicked()) {
                loadRoomsData();
            }
        } catch (IOException e) {
            showAlert("Ошибка", "Ошибка при открытии формы: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleDeleteRoom() {
        Room selectedRoom = roomsTable.getSelectionModel().getSelectedItem();
        if (selectedRoom == null) {
            showAlert("Предупреждение", "Пожалуйста, выберите номер для удаления", Alert.AlertType.WARNING);
            return;
        }

        Alert confirmDialog = new Alert(Alert.AlertType.CONFIRMATION);
        confirmDialog.setTitle("Подтверждение");
        confirmDialog.setHeaderText(null);
        confirmDialog.setContentText("Вы уверены, что хотите удалить этот номер?");

        Optional<ButtonType> result = confirmDialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("DELETE FROM rooms WHERE id = ?")) {

                stmt.setInt(1, selectedRoom.getId());
                int affected = stmt.executeUpdate();

                if (affected > 0) {
                    roomsList.remove(selectedRoom);
                    statusLabel.setText("Номер успешно удален");
                }

            } catch (SQLException e) {
                e.printStackTrace();
                showAlert("Ошибка", "Ошибка при удалении номера: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    private void handleRefreshRooms() {
        loadRoomsData();
    }

    // Методы для вкладки "Гости"
    private void loadGuestsData() {
        guestsList.clear();

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM persons")) {

            while (rs.next()) {
                Person person = new Person(
                        rs.getInt("id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("email"),
                        rs.getDate("birth_date")
                );
                guestsList.add(person);
            }

            statusLabel.setText("Загружено гостей: " + guestsList.size());

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Ошибка", "Ошибка при загрузке гостей: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleAddGuest() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/person_form.fxml"));
            Parent root = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Добавление гостя");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(guestsTable.getScene().getWindow());

            Scene scene = new Scene(root);
            dialogStage.setScene(scene);
            dialogStage.setMinWidth(400);
            dialogStage.setMinHeight(300);
            dialogStage.setWidth(400);
            dialogStage.setHeight(300);

            PersonFormController controller = loader.getController();
            Person newPerson = new Person(); // Создаем нового гостя
            controller.setPerson(newPerson);

            dialogStage.showAndWait();

            if (controller.isSaveClicked()) {
                // Сохраняем гостя в базу данных
                savePersonToDatabase(controller.getPerson());
                loadGuestsData(); // Обновляем таблицу
            }

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Ошибка", "Ошибка при открытии формы: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void savePersonToDatabase(Person person) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO persons (first_name, last_name, email, birth_date) VALUES (?, ?, ?, ?)",
                     PreparedStatement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, person.getFirstName());
            stmt.setString(2, person.getLastName());
            stmt.setString(3, person.getEmail());

            if (person.getBirthDate() != null) {
                stmt.setDate(4, new java.sql.Date(person.getBirthDate().getTime()));
            } else {
                stmt.setNull(4, java.sql.Types.DATE);
            }

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        person.setId(generatedKeys.getInt(1));
                        showAlert("Успех", "Гость успешно добавлен", Alert.AlertType.INFORMATION);
                    }
                }
            } else {
                showAlert("Ошибка", "Не удалось добавить гостя", Alert.AlertType.ERROR);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Ошибка сохранения", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleEditGuest() {
        Person selectedPerson = guestsTable.getSelectionModel().getSelectedItem();
        if (selectedPerson == null) {
            showAlert("Предупреждение", "Пожалуйста, выберите гостя для редактирования", Alert.AlertType.WARNING);
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/person_form.fxml"));
            Parent root = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Редактирование гостя");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(guestsTable.getScene().getWindow());

            Scene scene = new Scene(root);
            dialogStage.setScene(scene);
            dialogStage.setMinWidth(400);
            dialogStage.setMinHeight(300);
            dialogStage.setWidth(400);
            dialogStage.setHeight(300);

            PersonFormController controller = loader.getController();
            controller.setPerson(selectedPerson);

            dialogStage.showAndWait();

            if (controller.isSaveClicked()) {
                updatePersonInDatabase(selectedPerson);
                loadGuestsData();
            }

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Ошибка", "Ошибка при открытии формы: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void updatePersonInDatabase(Person person) {
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "UPDATE persons SET first_name = ?, last_name = ?, email = ?, birth_date = ? WHERE id = ?")) {

            stmt.setString(1, person.getFirstName());
            stmt.setString(2, person.getLastName());
            stmt.setString(3, person.getEmail());

            if (person.getBirthDate() != null) {
                stmt.setDate(4, new java.sql.Date(person.getBirthDate().getTime()));
            } else {
                stmt.setNull(4, java.sql.Types.DATE);
            }

            stmt.setInt(5, person.getId());

            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                showAlert("Успех", "Данные гостя успешно обновлены", Alert.AlertType.INFORMATION);
            } else {
                showAlert("Ошибка", "Не удалось обновить данные гостя", Alert.AlertType.ERROR);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Ошибка обновления", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleDeleteGuest() {
        Person selectedPerson = guestsTable.getSelectionModel().getSelectedItem();
        if (selectedPerson == null) {
            showAlert("Предупреждение", "Пожалуйста, выберите гостя для удаления", Alert.AlertType.WARNING);
            return;
        }

        Alert confirmDialog = new Alert(Alert.AlertType.CONFIRMATION);
        confirmDialog.setTitle("Подтверждение");
        confirmDialog.setHeaderText(null);
        confirmDialog.setContentText("Вы уверены, что хотите удалить этого гостя?");

        Optional<ButtonType> result = confirmDialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("DELETE FROM persons WHERE id = ?")) {

                stmt.setInt(1, selectedPerson.getId());
                int affected = stmt.executeUpdate();

                if (affected > 0) {
                    guestsList.remove(selectedPerson);
                    statusLabel.setText("Гость успешно удален");
                }

            } catch (SQLException e) {
                e.printStackTrace();
                showAlert("Ошибка", "Ошибка при удалении гостя: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    private void handleRefreshGuests() {
        loadGuestsData();
    }

    // Методы для вкладки "Бронирования"
    private void loadBookingsData() {
        bookingsList.clear();

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT b.*, p.first_name, p.last_name, r.room_number " +
                             "FROM bookings b " +
                             "JOIN persons p ON b.person_id = p.id " +
                             "JOIN rooms r ON b.room_id = r.id")) {

            while (rs.next()) {
                Booking booking = new Booking();
                booking.setId(rs.getInt("id"));
                booking.setPersonId(rs.getInt("person_id"));
                booking.setRoomId(rs.getInt("room_id"));
                booking.setCheckInDate(rs.getDate("check_in_date").toLocalDate());
                booking.setCheckOutDate(rs.getDate("check_out_date").toLocalDate());
                booking.setStatus(rs.getString("status"));
                booking.setGuestName(rs.getString("first_name") + " " + rs.getString("last_name"));
                booking.setRoomNumber(rs.getString("room_number"));

                bookingsList.add(booking);
            }

            statusLabel.setText("Загружено бронирований: " + bookingsList.size());

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Ошибка", "Ошибка при загрузке бронирований: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleAddBooking() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/booking_form.fxml"));
            Parent root = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Добавление бронирования");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(bookingsTable.getScene().getWindow());

            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            // Установка оптимального размера окна
            dialogStage.setMinWidth(700);
            dialogStage.setMinHeight(600);
            dialogStage.setWidth(700);
            dialogStage.setHeight(600);

            BookingFormController controller = loader.getController();
            controller.setGuestsList(guestsList);
            controller.setRoomsList(roomsList);
            controller.setServicesList(servicesList);

            dialogStage.showAndWait();

            if (controller.isSaveClicked()) {
                loadBookingsData();
            }

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Ошибка", "Ошибка при открытии формы: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleEditBooking() {
        Booking selectedBooking = bookingsTable.getSelectionModel().getSelectedItem();
        if (selectedBooking == null) {
            showAlert("Предупреждение", "Пожалуйста, выберите бронирование для редактирования", Alert.AlertType.WARNING);
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/booking_form.fxml"));
            Parent root = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Редактирование бронирования");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(bookingsTable.getScene().getWindow());

            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            // Установка оптимального размера окна
            dialogStage.setMinWidth(700);
            dialogStage.setMinHeight(600);
            dialogStage.setWidth(700);
            dialogStage.setHeight(600);

            BookingFormController controller = loader.getController();
            controller.setGuestsList(guestsList);
            controller.setRoomsList(roomsList);
            controller.setServicesList(servicesList);
            controller.setBooking(selectedBooking);

            dialogStage.showAndWait();

            if (controller.isSaveClicked()) {
                loadBookingsData();
            }

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Ошибка", "Ошибка при открытии формы: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleDeleteBooking() {
        Booking selectedBooking = bookingsTable.getSelectionModel().getSelectedItem();
        if (selectedBooking == null) {
            showAlert("Предупреждение", "Пожалуйста, выберите бронирование для удаления", Alert.AlertType.WARNING);
            return;
        }

        Alert confirmDialog = new Alert(Alert.AlertType.CONFIRMATION);
        confirmDialog.setTitle("Подтверждение");
        confirmDialog.setHeaderText(null);
        confirmDialog.setContentText("Вы уверены, что хотите удалить это бронирование?");

        Optional<ButtonType> result = confirmDialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("DELETE FROM bookings WHERE id = ?")) {

                stmt.setInt(1, selectedBooking.getId());
                int affected = stmt.executeUpdate();

                if (affected > 0) {
                    bookingsList.remove(selectedBooking);
                    statusLabel.setText("Бронирование успешно удалено");
                }

            } catch (SQLException e) {
                e.printStackTrace();
                showAlert("Ошибка", "Ошибка при удалении бронирования: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    private void handleRefreshBookings() {
        loadBookingsData();
    }

    // Методы для вкладки "Услуги"
    private void loadServicesData() {
        servicesList.clear();

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM services")) {

            while (rs.next()) {
                Service service = new Service(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getBigDecimal("price")
                );
                servicesList.add(service);
            }

            statusLabel.setText("Загружено услуг: " + servicesList.size());

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Ошибка", "Ошибка при загрузке услуг: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleAddService() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/service_form.fxml"));
            Parent root = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Добавление услуги");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(servicesTable.getScene().getWindow());

            // Установка оптимального размера окна
            Scene scene = new Scene(root);
            dialogStage.setScene(scene);
            dialogStage.setMinWidth(450);
            dialogStage.setMinHeight(300);
            dialogStage.setWidth(450);
            dialogStage.setHeight(300);

            ServiceFormController controller = loader.getController();
            controller.setService(new Service());

            dialogStage.showAndWait();

            if (controller.isSaveClicked()) {
                loadServicesData();
            }
        } catch (IOException e) {
            showAlert("Ошибка", "Ошибка при открытии формы: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleEditService() {
        Service selectedService = servicesTable.getSelectionModel().getSelectedItem();
        if (selectedService == null) {
            showAlert("Предупреждение", "Пожалуйста, выберите услугу для редактирования", Alert.AlertType.WARNING);
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/service_form.fxml"));
            Parent root = loader.load();

            Stage dialogStage = new Stage();
            dialogStage.setTitle("Редактирование услуги");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(servicesTable.getScene().getWindow());

            Scene scene = new Scene(root);
            dialogStage.setScene(scene);
            dialogStage.setMinWidth(450);
            dialogStage.setMinHeight(300);
            dialogStage.setWidth(450);
            dialogStage.setHeight(300);

            ServiceFormController controller = loader.getController();
            controller.setService(selectedService);

            dialogStage.showAndWait();

            if (controller.isSaveClicked()) {
                loadServicesData();
            }

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Ошибка", "Ошибка при открытии формы: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleDeleteService() {
        Service selectedService = servicesTable.getSelectionModel().getSelectedItem();
        if (selectedService == null) {
            showAlert("Предупреждение", "Пожалуйста, выберите услугу для удаления", Alert.AlertType.WARNING);
            return;
        }

        Alert confirmDialog = new Alert(Alert.AlertType.CONFIRMATION);
        confirmDialog.setTitle("Подтверждение");
        confirmDialog.setHeaderText(null);
        confirmDialog.setContentText("Вы уверены, что хотите удалить эту услугу?");

        Optional<ButtonType> result = confirmDialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement("DELETE FROM services WHERE id = ?")) {

                stmt.setInt(1, selectedService.getId());
                int affected = stmt.executeUpdate();

                if (affected > 0) {
                    servicesList.remove(selectedService);
                    statusLabel.setText("Услуга успешно удалена");
                }

            } catch (SQLException e) {
                e.printStackTrace();
                showAlert("Ошибка", "Ошибка при удалении услуги: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    private void handleRefreshServices() {
        loadServicesData();
    }

    // Общие методы
    @FXML
    private void handleNewBooking() {
        handleAddBooking();
    }

    @FXML
    private void showRoomsTab() {
        tabPane.getSelectionModel().select(roomsTab);
    }

    @FXML
    private void showGuestsTab() {
        tabPane.getSelectionModel().select(guestsTab);
    }

    @FXML
    private void showBookingsTab() {
        tabPane.getSelectionModel().select(bookingsTab);
    }

    @FXML
    private void showServicesTab() {
        tabPane.getSelectionModel().select(servicesTab);
    }

    @FXML
    private void handleLogout() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) tabPane.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setTitle("Вход в систему бронирования отеля");
            stage.setScene(scene);
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Ошибка", "Ошибка при выходе из системы: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleAbout() {
        Alert aboutDialog = new Alert(Alert.AlertType.INFORMATION);
        aboutDialog.setTitle("О программе");
        aboutDialog.setHeaderText("Система управления отелем");
        aboutDialog.setContentText("Версия: 98.431.0\nРазработчики: владик и максимка\n© 2025 Все права не защищены");
        aboutDialog.showAndWait();
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}