package com.example.controller;

import com.example.db.DatabaseConnection;
import com.example.model.Service;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ServiceFormController implements Initializable {

    @FXML
    private TextField nameField;

    @FXML
    private TextField priceField;

    @FXML
    private TextArea descriptionArea;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private Service service;
    private boolean saveClicked = false;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Инициализация контроллера
    }

    /**
     * Устанавливает услугу для редактирования
     */
    public void setService(Service service) {
        this.service = service;

        nameField.setText(service.getName() != null ? service.getName() : "");
        priceField.setText(service.getPrice() != null ? service.getPrice().toString() : "");
        descriptionArea.setText(service.getDescription() != null ? service.getDescription() : "");
    }

    /**
     * Возвращает true, если пользователь нажал Сохранить
     */
    public boolean isSaveClicked() {
        return saveClicked;
    }

    /**
     * Возвращает созданную/отредактированную услугу
     */
    public Service getService() {
        return service;
    }

    /**
     * Обработчик кнопки Сохранить
     */
    @FXML
    private void handleSave() {
        if (isInputValid()) {
            if (service == null) {
                service = new Service();
            }

            service.setName(nameField.getText());
            service.setPrice(new BigDecimal(priceField.getText()));
            service.setDescription(descriptionArea.getText());

            if (saveServiceToDatabase()) {
                saveClicked = true;
                closeDialog();
            }
        }
    }

    /**
     * Сохраняет услугу в базу данных
     */
    private boolean saveServiceToDatabase() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (service.getId() == 0) {
                // Новая услуга
                try (PreparedStatement stmt = conn.prepareStatement(
                        "INSERT INTO services (name, description, price) VALUES (?, ?, ?)",
                        PreparedStatement.RETURN_GENERATED_KEYS)) {

                    stmt.setString(1, service.getName());
                    stmt.setString(2, service.getDescription());
                    stmt.setBigDecimal(3, service.getPrice());

                    int rowsAffected = stmt.executeUpdate();

                    if (rowsAffected > 0) {
                        try (ResultSet rs = stmt.getGeneratedKeys()) {
                            if (rs.next()) {
                                service.setId(rs.getInt(1));
                                return true;
                            }
                        }
                    }
                }
            } else {
                // Существующая услуга
                try (PreparedStatement stmt = conn.prepareStatement(
                        "UPDATE services SET name = ?, description = ?, price = ? WHERE id = ?")) {

                    stmt.setString(1, service.getName());
                    stmt.setString(2, service.getDescription());
                    stmt.setBigDecimal(3, service.getPrice());
                    stmt.setInt(4, service.getId());

                    int rowsAffected = stmt.executeUpdate();
                    return rowsAffected > 0;
                }
            }
        } catch (SQLException e) {
            showAlert("Ошибка", "Ошибка при сохранении услуги: " + e.getMessage(), Alert.AlertType.ERROR);
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Обработчик кнопки Отмена
     */
    @FXML
    private void handleCancel() {
        closeDialog();
    }

    /**
     * Закрывает диалоговое окно
     */
    private void closeDialog() {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }

    /**
     * Проверяет валидность ввода пользователя
     */
    private boolean isInputValid() {
        String errorMessage = "";

        if (nameField.getText() == null || nameField.getText().isEmpty()) {
            errorMessage += "Название услуги не может быть пустым\n";
        }

        if (priceField.getText() == null || priceField.getText().isEmpty()) {
            errorMessage += "Цена не может быть пустой\n";
        } else {
            try {
                BigDecimal price = new BigDecimal(priceField.getText());
                if (price.compareTo(BigDecimal.ZERO) < 0) {
                    errorMessage += "Цена не может быть отрицательной\n";
                }
            } catch (NumberFormatException e) {
                errorMessage += "Цена должна быть числом\n";
            }
        }

        if (errorMessage.isEmpty()) {
            return true;
        } else {
            showAlert("Ошибка валидации", errorMessage, Alert.AlertType.ERROR);
            return false;
        }
    }

    /**
     * Показывает диалоговое окно с ошибкой
     */
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}