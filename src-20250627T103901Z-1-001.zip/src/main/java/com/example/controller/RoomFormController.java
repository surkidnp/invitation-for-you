package com.example.controller;

import com.example.db.DatabaseConnection;
import com.example.model.Room;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class RoomFormController implements Initializable {

    @FXML
    private TextField roomNumberField;

    @FXML
    private TextField roomTypeField;

    @FXML
    private TextField priceField;

    @FXML
    private TextField capacityField;

    @FXML
    private ComboBox<String> statusComboBox;

    @FXML
    private TextArea descriptionArea;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private Room room;
    private boolean saveClicked = false;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Инициализация статусов
        statusComboBox.setItems(FXCollections.observableArrayList(
                "AVAILABLE", "OCCUPIED", "MAINTENANCE", "RESERVED"));
        statusComboBox.getSelectionModel().selectFirst();
    }

    /**
     * Устанавливает номер для редактирования
     */
    public void setRoom(Room room) {
        this.room = room;

        roomNumberField.setText(room.getRoomNumber() != null ? room.getRoomNumber() : "");
        roomTypeField.setText(room.getRoomType() != null ? room.getRoomType() : "");
        priceField.setText(room.getPrice() != null ? room.getPrice().toString() : "");
        capacityField.setText(room.getCapacity() != 0 ? String.valueOf(room.getCapacity()) : "");
        statusComboBox.setValue(room.getStatus() != null ? room.getStatus() : "AVAILABLE");
        descriptionArea.setText(room.getDescription() != null ? room.getDescription() : "");
    }

    /**
     * Возвращает true, если пользователь нажал Сохранить
     */
    public boolean isSaveClicked() {
        return saveClicked;
    }

    /**
     * Возвращает созданный/отредактированный номер
     */
    public Room getRoom() {
        return room;
    }

    /**
     * Обработчик кнопки Сохранить
     */
    @FXML
    private void handleSave() {
        if (isInputValid()) {
            if (room == null) {
                room = new Room();
            }

            room.setRoomNumber(roomNumberField.getText());
            room.setRoomType(roomTypeField.getText());
            room.setPrice(new BigDecimal(priceField.getText()));
            room.setCapacity(Integer.parseInt(capacityField.getText()));
            room.setStatus(statusComboBox.getValue());
            room.setDescription(descriptionArea.getText());

            if (saveRoomToDatabase()) {
                saveClicked = true;
                closeDialog();
            }
        }
    }

    /**
     * Сохраняет номер в базу данных
     */
    private boolean saveRoomToDatabase() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            if (room.getId() == 0) {
                // Новый номер
                try (PreparedStatement stmt = conn.prepareStatement(
                        "INSERT INTO rooms (room_number, room_type, price, capacity, description, status) " +
                                "VALUES (?, ?, ?, ?, ?, ?)", PreparedStatement.RETURN_GENERATED_KEYS)) {

                    stmt.setString(1, room.getRoomNumber());
                    stmt.setString(2, room.getRoomType());
                    stmt.setBigDecimal(3, room.getPrice());
                    stmt.setInt(4, room.getCapacity());
                    stmt.setString(5, room.getDescription());
                    stmt.setString(6, room.getStatus());

                    int rowsAffected = stmt.executeUpdate();

                    if (rowsAffected > 0) {
                        try (ResultSet rs = stmt.getGeneratedKeys()) {
                            if (rs.next()) {
                                room.setId(rs.getInt(1));
                                return true;
                            }
                        }
                    }
                }
            } else {
                // Существующий номер
                try (PreparedStatement stmt = conn.prepareStatement(
                        "UPDATE rooms SET room_number = ?, room_type = ?, price = ?, " +
                                "capacity = ?, description = ?, status = ? WHERE id = ?")) {

                    stmt.setString(1, room.getRoomNumber());
                    stmt.setString(2, room.getRoomType());
                    stmt.setBigDecimal(3, room.getPrice());
                    stmt.setInt(4, room.getCapacity());
                    stmt.setString(5, room.getDescription());
                    stmt.setString(6, room.getStatus());
                    stmt.setInt(7, room.getId());

                    int rowsAffected = stmt.executeUpdate();
                    return rowsAffected > 0;
                }
            }
        } catch (SQLException e) {
            showAlert("Ошибка", "Ошибка при сохранении номера: " + e.getMessage(), Alert.AlertType.ERROR);
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Обработчик кнопки Отмена
     */
    @FXML
    private void handleCancel() {
        closeDialog();
    }

    /**
     * Закрывает диалоговое окно
     */
    private void closeDialog() {
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }

    /**
     * Проверяет валидность ввода пользователя
     */
    private boolean isInputValid() {
        String errorMessage = "";

        if (roomNumberField.getText() == null || roomNumberField.getText().isEmpty()) {
            errorMessage += "Номер комнаты не может быть пустым\n";
        }

        if (roomTypeField.getText() == null || roomTypeField.getText().isEmpty()) {
            errorMessage += "Тип номера не может быть пустым\n";
        }

        if (priceField.getText() == null || priceField.getText().isEmpty()) {
            errorMessage += "Цена не может быть пустой\n";
        } else {
            try {
                BigDecimal price = new BigDecimal(priceField.getText());
                if (price.compareTo(BigDecimal.ZERO) < 0) {
                    errorMessage += "Цена не может быть отрицательной\n";
                }
            } catch (NumberFormatException e) {
                errorMessage += "Цена должна быть числом\n";
            }
        }

        if (capacityField.getText() == null || capacityField.getText().isEmpty()) {
            errorMessage += "Вместимость не может быть пустой\n";
        } else {
            try {
                int capacity = Integer.parseInt(capacityField.getText());
                if (capacity <= 0) {
                    errorMessage += "Вместимость должна быть положительным числом\n";
                }
            } catch (NumberFormatException e) {
                errorMessage += "Вместимость должна быть целым числом\n";
            }
        }

        if (errorMessage.isEmpty()) {
            return true;
        } else {
            showAlert("Ошибка валидации", errorMessage, Alert.AlertType.ERROR);
            return false;
        }
    }

    /**
     * Показывает диалоговое окно с ошибкой
     */
    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}